import React from 'react';
import { useSelector } from 'react-redux';
import { Navigate } from 'react-router-dom';
import { Box, Typography, Button } from '@mui/material';
import { Security } from '@mui/icons-material';

const RoleBasedRoute = ({ children, roles, fallback = '/unauthorized' }) => {
  const { userRole, isAuthenticated } = useSelector((state) => state.auth);

  // If not authenticated, redirect to login
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Check if user has required role
  const hasRequiredRole = roles.includes(userRole);

  if (!hasRequiredRole) {
    // If fallback is a route, redirect to it
    if (fallback.startsWith('/')) {
      return <Navigate to={fallback} replace />;
    }

    // Otherwise, show custom fallback component
    return (
      <Box
        display="flex"
        flexDirection="column"
        alignItems="center"
        justifyContent="center"
        minHeight="60vh"
        textAlign="center"
        p={3}
      >
        <Security sx={{ fontSize: 64, color: 'warning.main', mb: 2 }} />
        <Typography variant="h4" gutterBottom>
          Access Denied
        </Typography>
        <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
          You don't have permission to access this page. Required roles: {roles.join(', ')}
        </Typography>
        <Button
          variant="contained"
          color="primary"
          onClick={() => window.history.back()}
        >
          Go Back
        </Button>
      </Box>
    );
  }

  return children;
};

export default RoleBasedRoute; 