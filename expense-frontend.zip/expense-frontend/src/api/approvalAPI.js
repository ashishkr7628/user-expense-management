import apiClient from './config';

export const approvalAPI = {
  // Get pending approvals
  getPendingApprovals: (params = {}) => {
    return apiClient.get('/expenses/pending', { params });
  },

  // Get approval history
  getApprovalHistory: (params = {}) => {
    return apiClient.get('/approvals/history', { params });
  },

  // Approve expense
  approveExpense: (expenseId) => {
    return apiClient.put(`/expenses/approve/${expenseId}?action=approve`);
  },

  // Reject expense
  rejectExpense: (expenseId) => {
    return apiClient.put(`/expenses/approve/${expenseId}?action=reject`);
  },

  // Bulk approve expenses
  bulkApprove: (expenseIds, approvalData) => {
    return apiClient.post('/approvals/bulk-approve', {
      expenseIds,
      ...approvalData,
    });
  },

  // Bulk reject expenses
  bulkReject: (expenseIds, rejectionData) => {
    return apiClient.post('/approvals/bulk-reject', {
      expenseIds,
      ...rejectionData,
    });
  },

  // Get approval workflow for expense
  getApprovalWorkflow: (expenseId) => {
    return apiClient.get(`/approvals/${expenseId}/workflow`);
  },

  // Get approval statistics
  getApprovalStats: (params = {}) => {
    return apiClient.get('/approvals/stats', { params });
  },

  // Get approval timeline
  getApprovalTimeline: (expenseId) => {
    return apiClient.get(`/approvals/${expenseId}/timeline`);
  },

  // Get approval comments
  getApprovalComments: (expenseId) => {
    return apiClient.get(`/approvals/${expenseId}/comments`);
  },

  // Add approval comment
  addApprovalComment: (expenseId, comment) => {
    return apiClient.post(`/approvals/${expenseId}/comments`, { comment });
  },

  // Get approval settings
  getApprovalSettings: () => {
    return apiClient.get('/approvals/settings');
  },

  // Update approval settings
  updateApprovalSettings: (settings) => {
    return apiClient.put('/approvals/settings', settings);
  },

  // Get approval levels
  getApprovalLevels: () => {
    return apiClient.get('/approvals/levels');
  },

  // Create approval level
  createApprovalLevel: (levelData) => {
    return apiClient.post('/approvals/levels', levelData);
  },

  // Update approval level
  updateApprovalLevel: (levelId, levelData) => {
    return apiClient.put(`/approvals/levels/${levelId}`, levelData);
  },

  // Delete approval level
  deleteApprovalLevel: (levelId) => {
    return apiClient.delete(`/approvals/levels/${levelId}`);
  },

  // Get approval rules
  getApprovalRules: () => {
    return apiClient.get('/approvals/rules');
  },

  // Create approval rule
  createApprovalRule: (ruleData) => {
    return apiClient.post('/approvals/rules', ruleData);
  },

  // Update approval rule
  updateApprovalRule: (ruleId, ruleData) => {
    return apiClient.put(`/approvals/rules/${ruleId}`, ruleData);
  },

  // Delete approval rule
  deleteApprovalRule: (ruleId) => {
    return apiClient.delete(`/approvals/rules/${ruleId}`);
  },

  // Get approval delegations
  getApprovalDelegations: () => {
    return apiClient.get('/approvals/delegations');
  },

  // Create approval delegation
  createApprovalDelegation: (delegationData) => {
    return apiClient.post('/approvals/delegations', delegationData);
  },

  // Update approval delegation
  updateApprovalDelegation: (delegationId, delegationData) => {
    return apiClient.put(`/approvals/delegations/${delegationId}`, delegationData);
  },

  // Delete approval delegation
  deleteApprovalDelegation: (delegationId) => {
    return apiClient.delete(`/approvals/delegations/${delegationId}`);
  },

  // Get approval notifications
  getApprovalNotifications: () => {
    return apiClient.get('/approvals/notifications');
  },

  // Mark approval notification as read
  markApprovalNotificationAsRead: (notificationId) => {
    return apiClient.put(`/approvals/notifications/${notificationId}/read`);
  },

  // Get approval reports
  getApprovalReports: (params = {}) => {
    return apiClient.get('/approvals/reports', { params });
  },

  // Export approval report
  exportApprovalReport: (params = {}) => {
    return apiClient.get('/approvals/reports/export', {
      params,
      responseType: 'blob',
    });
  },

  // Get approval analytics
  getApprovalAnalytics: (params = {}) => {
    return apiClient.get('/approvals/analytics', { params });
  },

  // Get approval trends
  getApprovalTrends: (params = {}) => {
    return apiClient.get('/approvals/trends', { params });
  },

  // Get approval performance
  getApprovalPerformance: (params = {}) => {
    return apiClient.get('/approvals/performance', { params });
  },

  // Get approval queue
  getApprovalQueue: (params = {}) => {
    return apiClient.get('/approvals/queue', { params });
  },

  // Reassign approval
  reassignApproval: (expenseId, reassignmentData) => {
    return apiClient.post(`/approvals/${expenseId}/reassign`, reassignmentData);
  },

  // Escalate approval
  escalateApproval: (expenseId, escalationData) => {
    return apiClient.post(`/approvals/${expenseId}/escalate`, escalationData);
  },

  // Get approval templates
  getApprovalTemplates: () => {
    return apiClient.get('/approvals/templates');
  },

  // Create approval template
  createApprovalTemplate: (templateData) => {
    return apiClient.post('/approvals/templates', templateData);
  },

  // Update approval template
  updateApprovalTemplate: (templateId, templateData) => {
    return apiClient.put(`/approvals/templates/${templateId}`, templateData);
  },

  // Delete approval template
  deleteApprovalTemplate: (templateId) => {
    return apiClient.delete(`/approvals/templates/${templateId}`);
  },

  // Get approval audit log
  getApprovalAuditLog: (params = {}) => {
    return apiClient.get('/approvals/audit-log', { params });
  },

  // Get approval dashboard data
  getApprovalDashboard: () => {
    return apiClient.get('/approvals/dashboard');
  },

  // Get approval calendar
  getApprovalCalendar: (params = {}) => {
    return apiClient.get('/approvals/calendar', { params });
  },

  // Get approval reminders
  getApprovalReminders: () => {
    return apiClient.get('/approvals/reminders');
  },

  // Send approval reminder
  sendApprovalReminder: (expenseId) => {
    return apiClient.post(`/approvals/${expenseId}/remind`);
  },

  // Get approval preferences
  getApprovalPreferences: () => {
    return apiClient.get('/approvals/preferences');
  },

  // Update approval preferences
  updateApprovalPreferences: (preferences) => {
    return apiClient.put('/approvals/preferences', preferences);
  },
}; 