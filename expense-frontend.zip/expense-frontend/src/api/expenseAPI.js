import apiClient from './config';

export const expenseAPI = {
  // Get all expenses with pagination and filters
  getExpenses: (params = {}) => {
    return apiClient.get('/expenses', { params });
  },

  // Get expense by ID
  getExpenseById: (id) => {
    return apiClient.get(`/expenses/${id}`);
  },

  // Create new expense
  createExpense: (expenseData) => {
    // expenseData: { title, amount, category, description }
    return apiClient.post('/expenses/create', expenseData);
  },

  // Update expense
  updateExpense: (id, expenseData) => {
    // expenseData: { title, amount, category }
    return apiClient.put(`/expenses/${id}`, expenseData);
  },

  // Delete expense
  deleteExpense: (id) => {
    return apiClient.delete(`/expenses/delete/${id}`);
  },

  // Submit expense for approval
  submitExpense: (id) => {
    return apiClient.post(`/expenses/${id}/submit`);
  },

  // Get expense categories
  getCategories: () => {
    return apiClient.get('/expenses/categories');
  },

  // Get expense statuses
  getStatuses: () => {
    return apiClient.get('/expenses/statuses');
  },

  // Upload receipt/invoice file
  uploadReceipt: (expenseId, file) => {
    const formData = new FormData();
    formData.append('file', file);
    return apiClient.post(`/expenses/${expenseId}/receipts`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  },

  // Delete receipt
  deleteReceipt: (expenseId, receiptId) => {
    return apiClient.delete(`/expenses/${expenseId}/receipts/${receiptId}`);
  },

  // Get receipt file
  getReceipt: (expenseId, receiptId) => {
    return apiClient.get(`/expenses/${expenseId}/receipts/${receiptId}`, {
      responseType: 'blob',
    });
  },

  // Bulk operations
  bulkDelete: (expenseIds) => {
    return apiClient.post('/expenses/bulk-delete', { expenseIds });
  },

  bulkSubmit: (expenseIds) => {
    return apiClient.post('/expenses/bulk-submit', { expenseIds });
  },

  // Export expenses
  exportExpenses: (params = {}) => {
    return apiClient.get('/expenses/export', {
      params,
      responseType: 'blob',
    });
  },

  // Get expense statistics
  getExpenseStats: (params = {}) => {
    return apiClient.get('/expenses/stats', { params });
  },

  // Get user's expense summary
  getExpenseSummary: (params = {}) => {
    return apiClient.get('/expenses/summary', { params });
  },

  // Get expense history
  getExpenseHistory: (expenseId) => {
    return apiClient.get(`/expenses/${expenseId}/history`);
  },

  // Add comment to expense
  addComment: (expenseId, comment) => {
    return apiClient.post(`/expenses/${expenseId}/comments`, { comment });
  },

  // Get expense comments
  getComments: (expenseId) => {
    return apiClient.get(`/expenses/${expenseId}/comments`);
  },

  // Delete comment
  deleteComment: (expenseId, commentId) => {
    return apiClient.delete(`/expenses/${expenseId}/comments/${commentId}`);
  },

  // Duplicate expense
  duplicateExpense: (expenseId) => {
    return apiClient.post(`/expenses/${expenseId}/duplicate`);
  },

  // Get expense templates
  getTemplates: () => {
    return apiClient.get('/expenses/templates');
  },

  // Create expense from template
  createFromTemplate: (templateId, expenseData) => {
    return apiClient.post(`/expenses/templates/${templateId}/create`, expenseData);
  },

  // Save expense as template
  saveAsTemplate: (expenseId, templateData) => {
    return apiClient.post(`/expenses/${expenseId}/save-template`, templateData);
  },

  // Get expense approval workflow
  getApprovalWorkflow: (expenseId) => {
    return apiClient.get(`/expenses/${expenseId}/workflow`);
  },

  // Get expense timeline
  getExpenseTimeline: (expenseId) => {
    return apiClient.get(`/expenses/${expenseId}/timeline`);
  },

  // Validate expense data
  validateExpense: (expenseData) => {
    return apiClient.post('/expenses/validate', expenseData);
  },

  // Get expense suggestions
  getSuggestions: (query) => {
    return apiClient.get('/expenses/suggestions', { params: { query } });
  },

  // Get expense analytics
  getExpenseAnalytics: (params = {}) => {
    return apiClient.get('/expenses/analytics', { params });
  },

  // Get expense trends
  getExpenseTrends: (params = {}) => {
    return apiClient.get('/expenses/trends', { params });
  },

  // Get expense comparison
  getExpenseComparison: (params = {}) => {
    return apiClient.get('/expenses/comparison', { params });
  },

  // Get expense forecast
  getExpenseForecast: (params = {}) => {
    return apiClient.get('/expenses/forecast', { params });
  },

  // Get expense alerts
  getExpenseAlerts: () => {
    return apiClient.get('/expenses/alerts');
  },

  // Mark alert as read
  markAlertAsRead: (alertId) => {
    return apiClient.put(`/expenses/alerts/${alertId}/read`);
  },

  // Get expense notifications
  getExpenseNotifications: () => {
    return apiClient.get('/expenses/notifications');
  },

  // Update notification preferences
  updateNotificationPreferences: (preferences) => {
    return apiClient.put('/expenses/notifications/preferences', preferences);
  },

  // Get my expenses (for EMPLOYEE)
  getMyExpenses: () => {
    return apiClient.get('/expenses/my');
  },

  // Approve expense (for MANAGER, ADMIN)
  approveExpense: (expenseId) => {
    return apiClient.put(`/expenses/approve/${expenseId}`);
  },

  // Get all expenses (for ADMIN)
  getAllExpenses: () => {
    return apiClient.get('/expenses/all');
  },
}; 