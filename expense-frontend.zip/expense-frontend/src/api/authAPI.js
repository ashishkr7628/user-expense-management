import apiClient from './config';

export const authAPI = {
  // Register new user
  register: (userData) => {
    // userData: { name, email, password, role }
    return apiClient.post('/users/register', userData);
  },

  // Login with email/password
  login: (credentials) => {
    // credentials: { email, password }
    return apiClient.post('/users/login', credentials);
  },

  // Refresh JWT token
  refreshToken: () => {
    const refreshToken = localStorage.getItem('refreshToken');
    return apiClient.post('/auth/refresh', { refreshToken });
  },

  // Logout user
  logout: () => {
    return apiClient.post('/auth/logout');
  },

  // Get current user profile
  getCurrentUser: () => {
    return apiClient.get('/users/profile');
  },

  // Update user profile
  updateProfile: (profileData) => {
    return apiClient.put('/auth/profile', profileData);
  },

  // Change password
  changePassword: (passwordData) => {
    return apiClient.post('/auth/change-password', passwordData);
  },

  // Request password reset
  requestPasswordReset: (email) => {
    return apiClient.post('/auth/forgot-password', { email });
  },

  // Reset password with token
  resetPassword: (resetData) => {
    return apiClient.post('/auth/reset-password', resetData);
  },

  // Verify email
  verifyEmail: (token) => {
    return apiClient.post('/auth/verify-email', { token });
  },

  // Resend verification email
  resendVerification: (email) => {
    return apiClient.post('/auth/resend-verification', { email });
  },

  // OAuth endpoints
  // Google OAuth
  googleAuth: (code) => {
    return apiClient.post('/auth/google', { code });
  },

  // GitHub OAuth
  githubAuth: (code) => {
    return apiClient.post('/auth/github', { code });
  },

  // Get OAuth URLs
  getOAuthUrl: (provider) => {
    const baseUrls = {
      google: 'https://accounts.google.com/oauth/authorize',
      github: 'https://github.com/login/oauth/authorize',
    };

    const params = {
      google: {
        client_id: import.meta.env.VITE_GOOGLE_CLIENT_ID,
        redirect_uri: `${window.location.origin}/oauth/callback/google`,
        response_type: 'code',
        scope: 'email profile',
      },
      github: {
        client_id: import.meta.env.VITE_GITHUB_CLIENT_ID,
        redirect_uri: `${window.location.origin}/oauth/callback/github`,
        response_type: 'code',
        scope: 'user:email',
      },
    };

    const url = new URL(baseUrls[provider]);
    Object.entries(params[provider]).forEach(([key, value]) => {
      url.searchParams.append(key, value);
    });

    return url.toString();
  },

  // Handle OAuth callback
  handleOAuthCallback: (provider, code) => {
    return apiClient.post(`/auth/${provider}/callback`, { code });
  },

  // Check if user is authenticated
  checkAuth: () => {
    const token = localStorage.getItem('token');
    if (!token) {
      return Promise.reject(new Error('No token found'));
    }
    return apiClient.get('/auth/check');
  },

  // Get user permissions
  getUserPermissions: () => {
    return apiClient.get('/auth/permissions');
  },

  // Get user roles
  getUserRoles: () => {
    return apiClient.get('/auth/roles');
  },
}; 