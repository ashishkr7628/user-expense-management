import axios from 'axios';
import { store } from '../store';
import { clearAuth, setToken } from '../store/slices/authSlice';
import { addNotification } from '../store/slices/uiSlice';

// API base URL configuration
const API_BASE_URL = import.meta.env.VITE_API_URL || '/api/';

// Create axios instance
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor - Add JWT token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor - Handle 401/403 errors and token refresh
apiClient.interceptors.response.use(
  (response) => {
    return response;
  },
  async (error) => {
    const originalRequest = error.config;

    // Handle 401 Unauthorized
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      try {
        const refreshToken = localStorage.getItem('refreshToken');
        if (refreshToken) {
          const response = await axios.post(`${API_BASE_URL}/auth/refresh`, {
            refreshToken,
          });

          const { token, refreshToken: newRefreshToken } = response.data;
          
          // Update tokens in store and localStorage
          store.dispatch(setToken(token));
          localStorage.setItem('token', token);
          localStorage.setItem('refreshToken', newRefreshToken);

          // Retry original request with new token
          originalRequest.headers.Authorization = `Bearer ${token}`;
          return apiClient(originalRequest);
        } else {
          // No refresh token available, logout user
          store.dispatch(clearAuth());
          store.dispatch(addNotification({
            type: 'error',
            message: 'Session expired. Please login again.',
          }));
          window.location.href = '/login';
        }
      } catch (refreshError) {
        // Refresh token failed, logout user
        store.dispatch(clearAuth());
        store.dispatch(addNotification({
          type: 'error',
          message: 'Session expired. Please login again.',
        }));
        window.location.href = '/login';
      }
    }

    // Handle 403 Forbidden
    if (error.response?.status === 403) {
      store.dispatch(addNotification({
        type: 'error',
        message: 'Access denied. You do not have permission to perform this action.',
      }));
    }

    // Handle network errors
    if (!error.response) {
      store.dispatch(addNotification({
        type: 'error',
        message: 'Network error. Please check your connection and try again.',
      }));
    }

    // Handle other errors
    if (error.response?.status >= 500) {
      store.dispatch(addNotification({
        type: 'error',
        message: 'Server error. Please try again later.',
      }));
    }

    return Promise.reject(error);
  }
);

// WebSocket configuration
export const WEBSOCKET_URL = import.meta.env.VITE_WEBSOCKET_URL || 'ws://localhost:8080/ws';

// OAuth configuration
export const OAUTH_CONFIG = {
  google: {
    clientId: import.meta.env.VITE_GOOGLE_CLIENT_ID,
    redirectUri: `${window.location.origin}/oauth/callback/google`,
  },
  github: {
    clientId: import.meta.env.VITE_GITHUB_CLIENT_ID,
    redirectUri: `${window.location.origin}/oauth/callback/github`,
  },
};

// File upload configuration
export const FILE_UPLOAD_CONFIG = {
  maxSize: 5 * 1024 * 1024, // 5MB
  allowedTypes: ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'],
  maxFiles: 5,
};

// Export the configured axios instance
export default apiClient; 