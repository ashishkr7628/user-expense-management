import apiClient from './config';

export const analyticsAPI = {
  // Get expense trends
  getExpenseTrends: (params = {}) => {
    return apiClient.get('/analytics/trends', { params });
  },

  // Get category breakdown
  getCategoryBreakdown: (params = {}) => {
    return apiClient.get('/analytics/categories', { params });
  },

  // Get monthly statistics
  getMonthlyStats: (params = {}) => {
    return apiClient.get('/analytics/monthly', { params });
  },

  // Get approval statistics
  getApprovalStats: (params = {}) => {
    return apiClient.get('/analytics/approvals', { params });
  },

  // Generate report
  generateReport: (reportParams) => {
    return apiClient.post('/analytics/reports', reportParams);
  },

  // Export report
  exportReport: (exportParams) => {
    return apiClient.get('/analytics/reports/export', {
      params: exportParams,
      responseType: 'blob',
    });
  },

  // Get dashboard analytics
  getDashboardAnalytics: (params = {}) => {
    return apiClient.get('/analytics/dashboard', { params });
  },

  // Get expense comparison
  getExpenseComparison: (params = {}) => {
    return apiClient.get('/analytics/comparison', { params });
  },

  // Get expense forecast
  getExpenseForecast: (params = {}) => {
    return apiClient.get('/analytics/forecast', { params });
  },

  // Get department analytics
  getDepartmentAnalytics: (params = {}) => {
    return apiClient.get('/analytics/departments', { params });
  },

  // Get user analytics
  getUserAnalytics: (params = {}) => {
    return apiClient.get('/analytics/users', { params });
  },

  // Get time-based analytics
  getTimeBasedAnalytics: (params = {}) => {
    return apiClient.get('/analytics/time-based', { params });
  },

  // Get cost center analytics
  getCostCenterAnalytics: (params = {}) => {
    return apiClient.get('/analytics/cost-centers', { params });
  },

  // Get project analytics
  getProjectAnalytics: (params = {}) => {
    return apiClient.get('/analytics/projects', { params });
  },

  // Get vendor analytics
  getVendorAnalytics: (params = {}) => {
    return apiClient.get('/analytics/vendors', { params });
  },

  // Get expense patterns
  getExpensePatterns: (params = {}) => {
    return apiClient.get('/analytics/patterns', { params });
  },

  // Get anomaly detection
  getAnomalyDetection: (params = {}) => {
    return apiClient.get('/analytics/anomalies', { params });
  },

  // Get budget vs actual
  getBudgetVsActual: (params = {}) => {
    return apiClient.get('/analytics/budget-vs-actual', { params });
  },

  // Get ROI analysis
  getROIAnalysis: (params = {}) => {
    return apiClient.get('/analytics/roi', { params });
  },

  // Get compliance analytics
  getComplianceAnalytics: (params = {}) => {
    return apiClient.get('/analytics/compliance', { params });
  },

  // Get audit analytics
  getAuditAnalytics: (params = {}) => {
    return apiClient.get('/analytics/audit', { params });
  },

  // Get performance metrics
  getPerformanceMetrics: (params = {}) => {
    return apiClient.get('/analytics/performance', { params });
  },

  // Get KPI dashboard
  getKPIDashboard: (params = {}) => {
    return apiClient.get('/analytics/kpi', { params });
  },

  // Get real-time analytics
  getRealTimeAnalytics: (params = {}) => {
    return apiClient.get('/analytics/realtime', { params });
  },

  // Get historical data
  getHistoricalData: (params = {}) => {
    return apiClient.get('/analytics/historical', { params });
  },

  // Get trend analysis
  getTrendAnalysis: (params = {}) => {
    return apiClient.get('/analytics/trend-analysis', { params });
  },

  // Get seasonal analysis
  getSeasonalAnalysis: (params = {}) => {
    return apiClient.get('/analytics/seasonal', { params });
  },

  // Get correlation analysis
  getCorrelationAnalysis: (params = {}) => {
    return apiClient.get('/analytics/correlation', { params });
  },

  // Get regression analysis
  getRegressionAnalysis: (params = {}) => {
    return apiClient.get('/analytics/regression', { params });
  },

  // Get clustering analysis
  getClusteringAnalysis: (params = {}) => {
    return apiClient.get('/analytics/clustering', { params });
  },

  // Get predictive analytics
  getPredictiveAnalytics: (params = {}) => {
    return apiClient.get('/analytics/predictive', { params });
  },

  // Get machine learning insights
  getMLInsights: (params = {}) => {
    return apiClient.get('/analytics/ml-insights', { params });
  },

  // Get data quality metrics
  getDataQualityMetrics: (params = {}) => {
    return apiClient.get('/analytics/data-quality', { params });
  },

  // Get data lineage
  getDataLineage: (params = {}) => {
    return apiClient.get('/analytics/data-lineage', { params });
  },

  // Get data governance metrics
  getDataGovernanceMetrics: (params = {}) => {
    return apiClient.get('/analytics/data-governance', { params });
  },

  // Get custom analytics
  getCustomAnalytics: (query) => {
    return apiClient.post('/analytics/custom', query);
  },

  // Save custom report
  saveCustomReport: (reportData) => {
    return apiClient.post('/analytics/reports/custom', reportData);
  },

  // Get saved reports
  getSavedReports: () => {
    return apiClient.get('/analytics/reports/saved');
  },

  // Update saved report
  updateSavedReport: (reportId, reportData) => {
    return apiClient.put(`/analytics/reports/saved/${reportId}`, reportData);
  },

  // Delete saved report
  deleteSavedReport: (reportId) => {
    return apiClient.delete(`/analytics/reports/saved/${reportId}`);
  },

  // Schedule report
  scheduleReport: (scheduleData) => {
    return apiClient.post('/analytics/reports/schedule', scheduleData);
  },

  // Get scheduled reports
  getScheduledReports: () => {
    return apiClient.get('/analytics/reports/scheduled');
  },

  // Update scheduled report
  updateScheduledReport: (scheduleId, scheduleData) => {
    return apiClient.put(`/analytics/reports/scheduled/${scheduleId}`, scheduleData);
  },

  // Delete scheduled report
  deleteScheduledReport: (scheduleId) => {
    return apiClient.delete(`/analytics/reports/scheduled/${scheduleId}`);
  },

  // Get analytics configuration
  getAnalyticsConfig: () => {
    return apiClient.get('/analytics/config');
  },

  // Update analytics configuration
  updateAnalyticsConfig: (config) => {
    return apiClient.put('/analytics/config', config);
  },

  // Get analytics permissions
  getAnalyticsPermissions: () => {
    return apiClient.get('/analytics/permissions');
  },

  // Get analytics audit log
  getAnalyticsAuditLog: (params = {}) => {
    return apiClient.get('/analytics/audit-log', { params });
  },

  // Export analytics data
  exportAnalyticsData: (params = {}) => {
    return apiClient.get('/analytics/export', {
      params,
      responseType: 'blob',
    });
  },

  // Get analytics health check
  getAnalyticsHealth: () => {
    return apiClient.get('/analytics/health');
  },

  // Get analytics version
  getAnalyticsVersion: () => {
    return apiClient.get('/analytics/version');
  },
}; 