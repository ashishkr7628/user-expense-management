import React from 'react';
import { Box, Typography, Card, CardContent, Grid } from '@mui/material';
import { SupervisorAccount } from '@mui/icons-material';

const ManagerDashboard = () => {
  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Manager Dashboard
      </Typography>
      <Typography variant="body1" color="textSecondary" mb={4}>
        Welcome to your manager expense management dashboard.
      </Typography>
      
      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Pending Approvals
              </Typography>
              <Typography variant="body2" color="textSecondary">
                Review and approve expense reports from your team.
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Team Analytics
              </Typography>
              <Typography variant="body2" color="textSecondary">
                View expense analytics and reports for your team.
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                My Expenses
              </Typography>
              <Typography variant="body2" color="textSecondary">
                Manage your own expense reports.
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default ManagerDashboard; 