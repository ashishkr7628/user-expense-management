import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  Chip,
  Avatar,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Divider,
  LinearProgress,
  IconButton,
  Tooltip,
  Paper,
} from '@mui/material';
import {
  Add,
  Receipt,
  Approval,
  TrendingUp,
  TrendingDown,
  AttachMoney,
  Schedule,
  CheckCircle,
  Cancel,
  Warning,
  MoreVert,
  Visibility,
  Edit,
  Delete,
} from '@mui/icons-material';
import { format } from 'date-fns';
import { toast } from 'react-toastify';
import { fetchMyExpenses } from '../../store/slices/expenseSlice';
import { fetchPendingApprovals } from '../../store/slices/approvalSlice';

const Dashboard = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user, userRole } = useSelector((state) => state.auth);
  const { expenses, isLoading: expensesLoading } = useSelector((state) => state.expenses);
  const { pendingApprovals, isLoading: approvalsLoading } = useSelector((state) => state.approvals);

  const [recentExpenses, setRecentExpenses] = useState([]);
  const [stats, setStats] = useState({
    totalExpenses: 0,
    pendingExpenses: 0,
    approvedExpenses: 0,
    totalAmount: 0,
    pendingAmount: 0,
    approvedAmount: 0,
  });

  useEffect(() => {
    // Load dashboard data based on user role
    const loadDashboardData = async () => {
      try {
        const promises = [
          dispatch(fetchMyExpenses()),
        ];
        if (userRole !== 'EMPLOYEE') {
          promises.push(dispatch(fetchPendingApprovals()));
        }
        await Promise.all(promises);
      } catch (error) {
        toast.error('Failed to load dashboard data');
      }
    };

    loadDashboardData();
  }, [dispatch, userRole]);

  useEffect(() => {
    if (expenses.length > 0) {
      setRecentExpenses(expenses.slice(0, 5));
      calculateStats();
    }
  }, [expenses]);

  const calculateStats = () => {
    const totalExpenses = expenses.length;
    const pendingExpenses = expenses.filter(exp => exp.status === 'PENDING_APPROVAL').length;
    const approvedExpenses = expenses.filter(exp => exp.status === 'APPROVED').length;
    
    const totalAmount = expenses.reduce((sum, exp) => sum + (exp.amount || 0), 0);
    const pendingAmount = expenses
      .filter(exp => exp.status === 'PENDING_APPROVAL')
      .reduce((sum, exp) => sum + (exp.amount || 0), 0);
    const approvedAmount = expenses
      .filter(exp => exp.status === 'APPROVED')
      .reduce((sum, exp) => sum + (exp.amount || 0), 0);

    setStats({
      totalExpenses,
      pendingExpenses,
      approvedExpenses,
      totalAmount,
      pendingAmount,
      approvedAmount,
    });
  };

  const getStatusColor = (status) => {
    const colors = {
      DRAFT: 'default',
      SUBMITTED: 'info',
      PENDING_APPROVAL: 'warning',
      APPROVED: 'success',
      REJECTED: 'error',
      PAID: 'success',
    };
    return colors[status] || 'default';
  };

  const getStatusIcon = (status) => {
    const icons = {
      DRAFT: <Schedule />,
      SUBMITTED: <Receipt />,
      PENDING_APPROVAL: <Warning />,
      APPROVED: <CheckCircle />,
      REJECTED: <Cancel />,
      PAID: <CheckCircle />,
    };
    return icons[status] || <Receipt />;
  };

  const StatCard = ({ title, value, subtitle, icon, color, onClick, isCurrency = false }) => (
    <Card
      sx={{
        height: '100%',
        cursor: onClick ? 'pointer' : 'default',
        transition: 'transform 0.2s, box-shadow 0.2s',
        '&:hover': onClick ? {
          transform: 'translateY(-4px)',
          boxShadow: 4,
        } : {},
      }}
      onClick={onClick}
    >
      <CardContent>
        <Box display="flex" alignItems="center" justifyContent="space-between">
          <Box>
            <Typography color="textSecondary" gutterBottom variant="body2">
              {title}
            </Typography>
            <Typography variant="h4" component="div" fontWeight="bold">
              {isCurrency
                ? (typeof value === 'number' ? `Rs ${value.toFixed(2)}` : value)
                : (typeof value === 'number' ? value : value)}
            </Typography>
            {subtitle && (
              <Typography variant="body2" color="textSecondary" sx={{ mt: 1 }}>
                {subtitle}
              </Typography>
            )}
          </Box>
          <Avatar
            sx={{
              bgcolor: `${color}.light`,
              color: `${color}.main`,
              width: 56,
              height: 56,
            }}
          >
            {icon}
          </Avatar>
        </Box>
      </CardContent>
    </Card>
  );

  const QuickActionCard = ({ title, description, icon, color, onClick }) => (
    <Card
      sx={{
        height: '100%',
        cursor: 'pointer',
        transition: 'transform 0.2s, box-shadow 0.2s',
        '&:hover': {
          transform: 'translateY(-4px)',
          boxShadow: 4,
        },
      }}
      onClick={onClick}
    >
      <CardContent sx={{ textAlign: 'center', py: 3 }}>
        <Avatar
          sx={{
            bgcolor: `${color}.light`,
            color: `${color}.main`,
            width: 64,
            height: 64,
            mx: 'auto',
            mb: 2,
          }}
        >
          {icon}
        </Avatar>
        <Typography variant="h6" gutterBottom>
          {title}
        </Typography>
        <Typography variant="body2" color="textSecondary">
          {description}
        </Typography>
      </CardContent>
    </Card>
  );

  const RecentActivityItem = ({ item, type }) => (
    <ListItem sx={{ px: 0 }}>
      <ListItemAvatar>
        <Avatar sx={{ bgcolor: 'primary.light' }}>
          {getStatusIcon(item.status)}
        </Avatar>
      </ListItemAvatar>
      <ListItemText
        primary={
          <Box display="flex" alignItems="center" gap={1}>
            <Typography variant="body2" fontWeight="medium">
              {type === 'expense' ? item.description : `Expense #${item.id}`}
            </Typography>
            <Chip
              label={item.status}
              size="small"
              color={getStatusColor(item.status)}
              variant="outlined"
            />
          </Box>
        }
        secondary={
          <Box>
            <Typography variant="body2" color="textSecondary">
              Rs {item.amount?.toFixed(2)} • {item.date ? format(new Date(item.date), 'PP') : 'N/A'}
            </Typography>
            {type === 'approval' && (
              <Typography variant="body2" color="textSecondary">
                Submitted by {item.submittedBy}
              </Typography>
            )}
          </Box>
        }
      />
      <IconButton size="small">
        <MoreVert />
      </IconButton>
    </ListItem>
  );

  return (
    <Box sx={{ maxHeight: '85vh', overflowY: 'auto', p: 2 }}>
      {/* Welcome Header */}
      <Box mb={4}>
        <Typography variant="h4" gutterBottom fontWeight="bold">
          Welcome back, {user?.firstName || user?.email}!
        </Typography>
        <Typography variant="body1" color="textSecondary">
          Here's what's happening with your expenses today.
        </Typography>
      </Box>

      {/* Statistics Cards */}
      <Grid container spacing={3} mb={4}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Total Expenses"
            value={stats.totalExpenses}
            subtitle="This month"
            icon={<Receipt />}
            color="primary"
            onClick={() => navigate('/expenses')}
            isCurrency={false}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Pending Expenses"
            value={stats.pendingExpenses}
            subtitle="Awaiting approval"
            icon={<Schedule />}
            color="warning"
            onClick={() => navigate('/expenses?status=PENDING_APPROVAL')}
            isCurrency={false}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Total Amount"
            value={stats.totalAmount}
            subtitle="This month"
            icon={<AttachMoney />}
            color="success"
            isCurrency={true}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Approved Amount"
            value={stats.approvedAmount}
            subtitle="This month"
            icon={<CheckCircle />}
            color="info"
            isCurrency={true}
          />
        </Grid>
      </Grid>

      {/* Quick Actions */}
      <Grid container spacing={3} mb={4}>
        <Grid item xs={12}>
          <Typography variant="h6" gutterBottom fontWeight="bold">
            Quick Actions
          </Typography>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <QuickActionCard
            title="New Expense"
            description="Create a new expense report"
            icon={<Add />}
            color="primary"
            onClick={() => navigate('/expenses/create')}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <QuickActionCard
            title="View Expenses"
            description="Browse all your expenses"
            icon={<Receipt />}
            color="info"
            onClick={() => navigate('/expenses')}
          />
        </Grid>
        {userRole !== 'EMPLOYEE' && (
          <Grid item xs={12} sm={6} md={3}>
            <QuickActionCard
              title="Pending Approvals"
              description="Review expense approvals"
              icon={<Approval />}
              color="warning"
              onClick={() => navigate('/approvals')}
            />
          </Grid>
        )}
        {userRole !== 'EMPLOYEE' && (
          <Grid item xs={12} sm={6} md={3}>
            <QuickActionCard
              title="Analytics"
              description="View expense analytics"
              icon={<TrendingUp />}
              color="success"
              onClick={() => navigate('/analytics')}
            />
          </Grid>
        )}
      </Grid>

      {/* Recent Activity and Pending Approvals */}
      <Grid container spacing={3}>
        {/* Recent Expenses */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between" mb={2}>
                <Typography variant="h6" fontWeight="bold">
                  Recent Expenses
                </Typography>
                <Button
                  size="small"
                  onClick={() => navigate('/expenses')}
                  endIcon={<Visibility />}
                >
                  View All
                </Button>
              </Box>
              {expensesLoading ? (
                <LinearProgress />
              ) : recentExpenses.length > 0 ? (
                <List sx={{ p: 0 }}>
                  {recentExpenses.map((expense, index) => (
                    <React.Fragment key={expense.id}>
                      <RecentActivityItem item={expense} type="expense" />
                      {index < recentExpenses.length - 1 && <Divider />}
                    </React.Fragment>
                  ))}
                </List>
              ) : (
                <Typography variant="body2" color="textSecondary" textAlign="center" py={3}>
                  No recent expenses
                </Typography>
              )}
            </CardContent>
          </Card>
        </Grid>

        {/* Pending Approvals (Manager/Admin only) */}
        {userRole !== 'EMPLOYEE' && (
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Box display="flex" alignItems="center" justifyContent="space-between" mb={2}>
                  <Typography variant="h6" fontWeight="bold">
                    Pending Approvals
                  </Typography>
                  <Button
                    size="small"
                    onClick={() => navigate('/approvals')}
                    endIcon={<Approval />}
                  >
                    View All
                  </Button>
                </Box>
                {approvalsLoading ? (
                  <LinearProgress />
                ) : pendingApprovals.length > 0 ? (
                  <List sx={{ p: 0 }}>
                    {pendingApprovals.slice(0, 5).map((approval, index) => (
                      <React.Fragment key={approval.id}>
                        <RecentActivityItem item={approval} type="approval" />
                        {index < Math.min(pendingApprovals.length, 5) - 1 && <Divider />}
                      </React.Fragment>
                    ))}
                  </List>
                ) : (
                  <Typography variant="body2" color="textSecondary" textAlign="center" py={3}>
                    No pending approvals
                  </Typography>
                )}
              </CardContent>
            </Card>
          </Grid>
        )}
      </Grid>
    </Box>
  );
};

export default Dashboard; 