import React from 'react';
import { Box, Typography, Card, CardContent, Grid } from '@mui/material';
import { Person } from '@mui/icons-material';

const EmployeeDashboard = () => {
  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Employee Dashboard
      </Typography>
      <Typography variant="body1" color="textSecondary" mb={4}>
        Welcome to your employee expense management dashboard.
      </Typography>
      
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                My Expenses
              </Typography>
              <Typography variant="body2" color="textSecondary">
                View and manage your expense reports.
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Submit New Expense
              </Typography>
              <Typography variant="body2" color="textSecondary">
                Create a new expense report for reimbursement.
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default EmployeeDashboard; 