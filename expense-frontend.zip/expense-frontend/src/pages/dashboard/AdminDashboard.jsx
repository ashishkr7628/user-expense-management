import React from 'react';
import { Box, Typography, Card, CardContent, Grid } from '@mui/material';
import { AdminPanelSettings } from '@mui/icons-material';

const AdminDashboard = () => {
  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Admin Dashboard
      </Typography>
      <Typography variant="body1" color="textSecondary" mb={4}>
        Welcome to your admin expense management dashboard.
      </Typography>
      
      <Grid container spacing={3}>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                User Management
              </Typography>
              <Typography variant="body2" color="textSecondary">
                Manage users, roles, and permissions.
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                System Analytics
              </Typography>
              <Typography variant="body2" color="textSecondary">
                View comprehensive system analytics and reports.
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Approval Workflows
              </Typography>
              <Typography variant="body2" color="textSecondary">
                Configure approval workflows and rules.
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default AdminDashboard; 