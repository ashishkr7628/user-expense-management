import React from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Box, Typography, Card, CardContent, TextField, Button, MenuItem, CircularProgress, Alert } from '@mui/material';
import { createExpense } from '../../store/slices/expenseSlice';
import { format } from 'date-fns';

const categories = [
  'Travel',
  'Meals',
  'Office Supplies',
  'Equipment',
  'Software',
  'Training',
  'Other',
];

const ExpenseCreate = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm();

  const onSubmit = async (data) => {
    try {
      const expenseData = {
        ...data,
        approverRole: 'MANAGER',
        date: format(new Date(), 'yyyy-MM-dd'),
      };
      await dispatch(createExpense(expenseData)).unwrap();
      navigate('/expenses');
    } catch (err) {
      // error handled by slice
    }
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Create New Expense
      </Typography>
      <Typography variant="body1" color="textSecondary" mb={4}>
        Submit a new expense report for reimbursement.
      </Typography>
      
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Expense Form
          </Typography>
          <form onSubmit={handleSubmit(onSubmit)}>
            <TextField
              label="Title"
              fullWidth
              margin="normal"
              {...register('title', { required: 'Title is required' })}
              error={!!errors.title}
              helperText={errors.title?.message}
            />
            <TextField
              label="Amount"
              fullWidth
              margin="normal"
              type="number"
              {...register('amount', { required: 'Amount is required', min: { value: 1, message: 'Amount must be positive' } })}
              error={!!errors.amount}
              helperText={errors.amount?.message}
            />
            <TextField
              label="Category"
              fullWidth
              margin="normal"
              select
              defaultValue="Travel"
              {...register('category', { required: 'Category is required' })}
              error={!!errors.category}
              helperText={errors.category?.message}
            >
              {categories.map((cat) => (
                <MenuItem key={cat} value={cat}>{cat}</MenuItem>
              ))}
            </TextField>
            <TextField
              label="Description"
              fullWidth
              margin="normal"
              multiline
              minRows={2}
              {...register('description', { required: 'Description is required' })}
              error={!!errors.description}
              helperText={errors.description?.message}
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 2 }}
              disabled={isSubmitting}
            >
              {isSubmitting ? <CircularProgress size={24} /> : 'Create Expense'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </Box>
  );
};

export default ExpenseCreate; 