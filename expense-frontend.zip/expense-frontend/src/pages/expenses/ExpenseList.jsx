import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Box, Card, CardContent, Typography, Button, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Chip, IconButton, CircularProgress } from '@mui/material';
import { Add, Edit, Delete } from '@mui/icons-material';
import { fetchMyExpenses, fetchAllExpenses, deleteExpense } from '../../store/slices/expenseSlice';

const ExpenseList = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { expenses, isLoading } = useSelector((state) => state.expenses);
  const { userRole } = useSelector((state) => state.auth);

  useEffect(() => {
    if (userRole === 'ADMIN') {
      dispatch(fetchAllExpenses());
    } else {
      dispatch(fetchMyExpenses());
    }
  }, [dispatch, userRole]);

  const handleDelete = (id) => {
    dispatch(deleteExpense(id));
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" fontWeight="bold">Expenses</Typography>
        <Button variant="contained" startIcon={<Add />} onClick={() => navigate('/expenses/create')}>
          New Expense
        </Button>
      </Box>
      <Card>
        <CardContent>
          {isLoading ? (
            <Box display="flex" justifyContent="center" alignItems="center" minHeight={200}>
              <CircularProgress />
            </Box>
          ) : (
            <TableContainer component={Paper} variant="outlined">
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Title</TableCell>
                    <TableCell>Amount</TableCell>
                    <TableCell>Category</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {expenses.map((expense) => (
                    <TableRow key={expense.id} hover>
                      <TableCell>{expense.title}</TableCell>
                      <TableCell>{'Rs ' + expense.amount}</TableCell>
                      <TableCell>{expense.category}</TableCell>
                      <TableCell>
                        <Chip label={expense.status} color={expense.status === 'APPROVED' ? 'success' : expense.status === 'REJECTED' ? 'error' : 'warning'} size="small" />
                      </TableCell>
                      <TableCell>
                        <IconButton onClick={() => navigate(`/expenses/${expense.id}/edit`)}><Edit /></IconButton>
                        <IconButton onClick={() => handleDelete(expense.id)}><Delete /></IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </CardContent>
      </Card>
    </Box>
  );
};

export default ExpenseList; 