import React from 'react';
import { Box, Typography, Card, CardContent } from '@mui/material';

const ExpenseDetail = () => {
  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Expense Details
      </Typography>
      <Typography variant="body1" color="textSecondary" mb={4}>
        View detailed information about this expense report.
      </Typography>
      
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Expense Information
          </Typography>
          <Typography variant="body2" color="textSecondary">
            Detailed expense view will be implemented here with all expense information, status tracking, and approval workflow.
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
};

export default ExpenseDetail; 