import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Box, Typography, Card, CardContent, TextField, Button, MenuItem, CircularProgress, Alert } from '@mui/material';
import axios from 'axios';

const categories = [
  'Travel',
  'Meals',
  'Office Supplies',
  'Equipment',
  'Software',
  'Training',
  'Other',
];

const ExpenseEdit = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [formData, setFormData] = useState({
    title: '',
    amount: '',
    category: '',
    description: '',
    date: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Fetch existing expense data
  useEffect(() => {
    const fetchExpense = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await fetch(`http://localhost:5173/api/expenses/my/${id}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        });
        if (!response.ok) throw new Error('Failed to fetch expense');
        const data = await response.json();
        setFormData({
          title: data.title || '',
          amount: data.amount || '',
          category: data.category || '',
          description: data.description || '',
          date: data.date || ''
        });
      } catch (err) {
        setError(err.message);
      }
    };
    fetchExpense();
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `http://localhost:5173/api/expenses/edit/${id}`,
        formData,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
        }
      );
      navigate('/expenses');
    } catch (err) {
      setError(err.response?.data?.message || err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ maxHeight: '85vh', overflowY: 'auto', p: 2 }}>
      <Button variant="outlined" onClick={() => navigate(-1)} sx={{ mb: 2 }}>
        Back
      </Button>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Edit Expense
      </Typography>
      <Typography variant="body1" color="textSecondary" mb={4}>
        Update your expense report details.
      </Typography>
      
      <Card>
        <CardContent>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
          <form onSubmit={handleSubmit}>
            <TextField
              label="Title"
              name="title"
              value={formData.title}
              onChange={handleChange}
              fullWidth
              margin="normal"
              required
            />
            <TextField
              label="Amount"
              name="amount"
              type="number"
              value={formData.amount}
              onChange={handleChange}
              fullWidth
              margin="normal"
              required
            />
            <TextField
              label="Category"
              name="category"
              select
              value={formData.category}
              onChange={handleChange}
              fullWidth
              margin="normal"
              required
            >
              {categories.map((cat) => (
                <MenuItem key={cat} value={cat}>{cat}</MenuItem>
              ))}
            </TextField>
            <TextField
              label="Description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              fullWidth
              margin="normal"
              multiline
              minRows={2}
              required
            />
            <Button
              type="submit"
              variant="contained"
              fullWidth
              sx={{ mt: 2 }}
              disabled={loading}
            >
              {loading ? <CircularProgress size={24} /> : 'Update Expense'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </Box>
  );
};

export default ExpenseEdit; 