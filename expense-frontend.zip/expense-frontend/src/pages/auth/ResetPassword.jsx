import React from 'react';
import { Box, Typography, Paper } from '@mui/material';

const ResetPassword = () => {
  return (
    <Box sx={{ mt: 10, display: 'flex', justifyContent: 'center' }}>
      <Paper elevation={3} sx={{ p: 4, width: 400 }}>
        <Typography variant="h5" gutterBottom>Reset Password</Typography>
        <Typography variant="body1" color="textSecondary">
          Password reset functionality will be implemented here.
        </Typography>
      </Paper>
    </Box>
  );
};

export default ResetPassword; 