import React from 'react';
import { Box, Typography, Paper, CircularProgress } from '@mui/material';

const OAuthCallback = () => {
  return (
    <Box sx={{ mt: 10, display: 'flex', justifyContent: 'center' }}>
      <Paper elevation={3} sx={{ p: 4, width: 400, textAlign: 'center' }}>
        <CircularProgress sx={{ mb: 2 }} />
        <Typography variant="h5" gutterBottom>Processing OAuth Login</Typography>
        <Typography variant="body1" color="textSecondary">
          Please wait while we complete your authentication...
        </Typography>
      </Paper>
    </Box>
  );
};

export default OAuthCallback; 