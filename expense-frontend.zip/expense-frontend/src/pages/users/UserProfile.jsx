import React, { useEffect, useState } from 'react';
import { Box, Typography, Card, CardContent, CircularProgress, Alert, Avatar } from '@mui/material';

const UserProfile = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProfile = async () => {
      setLoading(true);
      setError(null);
      try {
        const token = localStorage.getItem('token');
        const res = await fetch('http://localhost:5173/api/users/profile', {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
        });
        if (!res.ok) throw new Error('Failed to fetch profile');
        const data = await res.json();
        setUser(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchProfile();
  }, []);

  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        My Profile
      </Typography>
      <Card>
        <CardContent>
          {loading && <CircularProgress sx={{ my: 2 }} />}
          {error && <Alert severity="error" sx={{ my: 2 }}>{error}</Alert>}
          {user && (
            <Box display="flex" alignItems="center" gap={3}>
              <Avatar sx={{ width: 64, height: 64, fontSize: 32 }}>
                {user.firstName ? user.firstName[0] : user.email[0]}
              </Avatar>
              <Box>
                <Typography variant="h6" gutterBottom>
                  {user.firstName} {user.lastName}
                </Typography>
                <Typography variant="body1" color="textSecondary">
                  Email: {user.email}
                </Typography>
                <Typography variant="body1" color="textSecondary">
                  Role: {user.role}
                </Typography>
              </Box>
            </Box>
          )}
        </CardContent>
      </Card>
    </Box>
  );
};

export default UserProfile; 