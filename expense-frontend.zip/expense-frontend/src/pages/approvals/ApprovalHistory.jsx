import React from 'react';
import { Box, Typography, Card, CardContent } from '@mui/material';

const ApprovalHistory = () => {
  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Approval History
      </Typography>
      <Typography variant="body1" color="textSecondary" mb={4}>
        View history of all approved and rejected expense reports.
      </Typography>
      
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Approval History
          </Typography>
          <Typography variant="body2" color="textSecondary">
            Approval history with filtering, search, and detailed audit trail will be implemented here.
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
};

export default ApprovalHistory; 