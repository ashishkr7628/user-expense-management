import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Box, Typography, Card, TableContainer, Table, TableHead, TableRow, TableCell, TableBody, Button, CircularProgress, Alert } from '@mui/material';
import { fetchPendingApprovals, approveExpense, rejectExpense } from '../../store/slices/approvalSlice';
import { format } from 'date-fns';

const ApprovalList = () => {
  const dispatch = useDispatch();
  const { pendingApprovals, isLoading, error } = useSelector((state) => state.approvals);

  useEffect(() => {
    dispatch(fetchPendingApprovals());
  }, [dispatch]);

  const handleApprove = (expenseId) => {
    dispatch(approveExpense(expenseId));
  };

  const handleReject = (expenseId) => {
    dispatch(rejectExpense(expenseId));
  };

  if (isLoading && !pendingApprovals.length) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="50vh">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return <Alert severity="error">Failed to load pending approvals: {error}</Alert>;
  }

  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Pending Approvals
      </Typography>
      <Typography variant="body1" color="textSecondary" mb={4}>
        Review and process expense reports that require your approval.
      </Typography>
      
      <Card>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Submitted By</TableCell>
                <TableCell>Title</TableCell>
                <TableCell>Amount</TableCell>
                <TableCell>Category</TableCell>
                <TableCell>Date Submitted</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {pendingApprovals.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} align="center">
                    No pending approvals at the moment.
                  </TableCell>
                </TableRow>
              ) : (
                pendingApprovals.map((expense) => (
                  <TableRow key={expense.id}>
                    <TableCell>{expense.user.name}</TableCell>
                    <TableCell>{expense.title}</TableCell>
                    <TableCell>${expense.amount.toFixed(2)}</TableCell>
                    <TableCell>{expense.category}</TableCell>
                    <TableCell>{expense.date ? format(new Date(expense.date), 'PP') : 'N/A'}</TableCell>
                    <TableCell align="right">
                      <Button variant="contained" color="success" size="small" onClick={() => handleApprove(expense.id)} sx={{ mr: 1 }}>
                        Approve
                      </Button>
                      <Button variant="contained" color="error" size="small" onClick={() => handleReject(expense.id)}>
                        Reject
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Card>
    </Box>
  );
};

export default ApprovalList; 