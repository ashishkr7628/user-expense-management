import React from 'react';
import { Box, Typography, Card, CardContent } from '@mui/material';

const ApprovalDetail = () => {
  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Approval Details
      </Typography>
      <Typography variant="body1" color="textSecondary" mb={4}>
        Review expense details and make approval decision.
      </Typography>
      
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Approval Decision
          </Typography>
          <Typography variant="body2" color="textSecondary">
            Detailed approval view with expense information, comments, and approval/rejection actions will be implemented here.
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
};

export default ApprovalDetail; 