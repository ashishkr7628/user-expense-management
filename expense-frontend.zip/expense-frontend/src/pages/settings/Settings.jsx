import React from 'react';
import { Box, Typography, Card, CardContent } from '@mui/material';

const Settings = () => {
  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Settings
      </Typography>
      <Typography variant="body1" color="textSecondary" mb={4}>
        Manage your account settings and preferences.
      </Typography>
      
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            General Settings
          </Typography>
          <Typography variant="body2" color="textSecondary">
            Settings page will be implemented here with various configuration options.
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
};

export default Settings; 