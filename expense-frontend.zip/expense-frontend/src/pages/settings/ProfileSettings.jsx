import React from 'react';
import { Box, Typography, Card, CardContent } from '@mui/material';

const ProfileSettings = () => {
  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Profile Settings
      </Typography>
      <Typography variant="body1" color="textSecondary" mb={4}>
        Update your profile information and personal details.
      </Typography>
      
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Profile Information
          </Typography>
          <Typography variant="body2" color="textSecondary">
            Profile settings form will be implemented here with user information fields.
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
};

export default ProfileSettings; 