import React from 'react';
import { Box, Typography, Card, CardContent } from '@mui/material';

const NotificationSettings = () => {
  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Notification Settings
      </Typography>
      <Typography variant="body1" color="textSecondary" mb={4}>
        Configure your notification preferences and alerts.
      </Typography>
      
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Notification Preferences
          </Typography>
          <Typography variant="body2" color="textSecondary">
            Notification settings will be implemented here with various notification options.
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
};

export default NotificationSettings; 