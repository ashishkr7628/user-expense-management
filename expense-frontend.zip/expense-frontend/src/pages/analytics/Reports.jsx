import React, { useEffect, useState } from 'react';
import * as XLSX from 'xlsx';
import axios from 'axios';

const Reports = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchExpenses = async () => {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5173/api/expenses/all', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setData(res.data);
    };
    fetchExpenses();
  }, []);

  useEffect(() => {
    if (data.length > 0) {
      const worksheet = XLSX.utils.json_to_sheet(
        data.map(row => ({
          Date: row.date,
          Title: row.title,
          Description: row.description,
          Category: row.category,
          Amount: row.amount
        }))
      );
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Expenses');
      XLSX.writeFile(workbook, 'expenses_report.xlsx');
    }
  }, [data]);

  return null; // No button needed, download happens automatically
};

export default Reports;