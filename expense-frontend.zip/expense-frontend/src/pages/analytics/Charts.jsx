import React from 'react';
import { Box, Typography, Card, CardContent } from '@mui/material';

const Charts = () => {
  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Charts
      </Typography>
      <Typography variant="body1" color="textSecondary" mb={4}>
        Interactive charts and visualizations.
      </Typography>
      
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Chart Gallery
          </Typography>
          <Typography variant="body2" color="textSecondary">
            Various chart types including line charts, bar charts, pie charts, and dashboards will be implemented here.
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
};

export default Charts; 