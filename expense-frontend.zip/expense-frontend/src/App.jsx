import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { Box, CircularProgress } from '@mui/material';
import { getCurrentUser, clearAuth } from './store/slices/authSlice';
import { addNotification } from './store/slices/uiSlice';

// Layout Components
import Layout from './components/layout/Layout';
import ProtectedRoute from './components/auth/ProtectedRoute';
import RoleBasedRoute from './components/auth/RoleBasedRoute';

// Authentication Pages
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import ForgotPassword from './pages/auth/ForgotPassword';
import ResetPassword from './pages/auth/ResetPassword';
import OAuthCallback from './pages/auth/OAuthCallback';

// Dashboard Pages
import Dashboard from './pages/dashboard/Dashboard';
import EmployeeDashboard from './pages/dashboard/EmployeeDashboard';
import ManagerDashboard from './pages/dashboard/ManagerDashboard';
import AdminDashboard from './pages/dashboard/AdminDashboard';

// Expense Pages
import ExpenseList from './pages/expenses/ExpenseList';
import ExpenseCreate from './pages/expenses/ExpenseCreate';
import ExpenseEdit from './pages/expenses/ExpenseEdit';
import ExpenseDetail from './pages/expenses/ExpenseDetail';

// Approval Pages
import ApprovalList from './pages/approvals/ApprovalList';
import ApprovalHistory from './pages/approvals/ApprovalHistory';
import ApprovalDetail from './pages/approvals/ApprovalDetail';

// Analytics Pages
import Analytics from './pages/analytics/Analytics';
import Reports from './pages/analytics/Reports';
import Charts from './pages/analytics/Charts';

// User Management Pages
import UserList from './pages/users/UserList';
import UserProfile from './pages/users/UserProfile';
import UserEdit from './pages/users/UserEdit';

// Settings Pages
import Settings from './pages/settings/Settings';
import ProfileSettings from './pages/settings/ProfileSettings';
import NotificationSettings from './pages/settings/NotificationSettings';

// Error Pages
import NotFound from './pages/errors/NotFound';
import Unauthorized from './pages/errors/Unauthorized';

function App() {
  const dispatch = useDispatch();
  const { isAuthenticated, isLoading, user } = useSelector((state) => state.auth);

  useEffect(() => {
    // On every reload, if token exists, always fetch user profile
    const token = localStorage.getItem('token');
    if (token) {
      dispatch(getCurrentUser());
    }
  }, [dispatch]);

  useEffect(() => {
    // Show welcome notification for authenticated users
    if (isAuthenticated && user) {
      dispatch(addNotification({
        type: 'success',
        message: `Welcome back, ${user.name || user.email}!`,
      }));
    }
  }, [isAuthenticated, user, dispatch]);

  if (isLoading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        minHeight="100vh"
      >
        <CircularProgress size={60} />
      </Box>
    );
  }

  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={!isAuthenticated ? <Login /> : <Navigate to="/dashboard" />} />
        <Route path="/register" element={!isAuthenticated ? <Register /> : <Navigate to="/dashboard" />} />
        <Route path="/forgot-password" element={!isAuthenticated ? <ForgotPassword /> : <Navigate to="/dashboard" />} />
        <Route path="/reset-password" element={!isAuthenticated ? <ResetPassword /> : <Navigate to="/dashboard" />} />
        <Route path="/oauth/callback/:provider" element={<OAuthCallback />} />

        {/* Protected Routes with Layout */}
        <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
          {/* Dashboard Routes */}
          <Route index element={<Navigate to="/dashboard" />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="dashboard/employee" element={<RoleBasedRoute roles={['EMPLOYEE']}><EmployeeDashboard /></RoleBasedRoute>} />
          <Route path="dashboard/manager" element={<RoleBasedRoute roles={['MANAGER', 'ADMIN']}><ManagerDashboard /></RoleBasedRoute>} />
          <Route path="dashboard/admin" element={<RoleBasedRoute roles={['ADMIN']}><AdminDashboard /></RoleBasedRoute>} />

          {/* Expense Routes */}
          <Route path="expenses" element={<ExpenseList />} />
          <Route path="expenses/create" element={<ExpenseCreate />} />
          <Route path="expenses/:id" element={<ExpenseDetail />} />
          <Route path="expenses/:id/edit" element={<ExpenseEdit />} />

          {/* Approval Routes (Manager/Admin only) */}
          <Route path="approvals" element={<RoleBasedRoute roles={['MANAGER', 'ADMIN']}><ApprovalList /></RoleBasedRoute>} />
          <Route path="approvals/history" element={<RoleBasedRoute roles={['MANAGER', 'ADMIN']}><ApprovalHistory /></RoleBasedRoute>} />
          <Route path="approvals/:id" element={<RoleBasedRoute roles={['MANAGER', 'ADMIN']}><ApprovalDetail /></RoleBasedRoute>} />

          {/* Analytics Routes */}
          <Route path="analytics" element={<RoleBasedRoute roles={['MANAGER', 'ADMIN']}><Analytics /></RoleBasedRoute>} />
          <Route path="analytics/reports" element={<RoleBasedRoute roles={['MANAGER', 'ADMIN']}><Reports /></RoleBasedRoute>} />
          <Route path="analytics/charts" element={<RoleBasedRoute roles={['MANAGER', 'ADMIN']}><Charts /></RoleBasedRoute>} />

          {/* User Management Routes (Admin only) */}
          <Route path="users" element={<RoleBasedRoute roles={['ADMIN']}><UserList /></RoleBasedRoute>} />
          <Route path="users/:id" element={<UserProfile />} />
          <Route path="users/:id/edit" element={<RoleBasedRoute roles={['ADMIN']}><UserEdit /></RoleBasedRoute>} />
          <Route path="profile" element={<UserProfile />} />
        </Route>

        {/* Error Routes */}
        <Route path="/unauthorized" element={<Unauthorized />} />
        <Route path="/404" element={<NotFound />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  );
}

export default App;
