import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { expenseAPI } from '../../api/expenseAPI';

// Async thunks
export const fetchMyExpenses = createAsyncThunk(
  'expenses/fetchMyExpenses',
  async (_, { rejectWithValue }) => {
    try {
      const response = await expenseAPI.getMyExpenses();
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to fetch expenses');
    }
  }
);

export const fetchAllExpenses = createAsyncThunk(
  'expenses/fetchAllExpenses',
  async (_, { rejectWithValue }) => {
    try {
      const response = await expenseAPI.getAllExpenses();
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to fetch all expenses');
    }
  }
);

export const createExpense = createAsyncThunk(
  'expenses/createExpense',
  async (expenseData, { rejectWithValue }) => {
    try {
      const response = await expenseAPI.createExpense(expenseData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to create expense');
    }
  }
);

export const updateExpense = createAsyncThunk(
  'expenses/updateExpense',
  async ({ id, expenseData }, { rejectWithValue }) => {
    try {
      const response = await expenseAPI.updateExpense(id, expenseData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to update expense');
    }
  }
);

export const deleteExpense = createAsyncThunk(
  'expenses/deleteExpense',
  async (id, { rejectWithValue }) => {
    try {
      await expenseAPI.deleteExpense(id);
      return id;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to delete expense');
    }
  }
);

export const approveExpense = createAsyncThunk(
  'expenses/approveExpense',
  async (expenseId, { rejectWithValue }) => {
    try {
      const response = await expenseAPI.approveExpense(expenseId);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to approve expense');
    }
  }
);

const initialState = {
  expenses: [],
  isLoading: false,
  error: null,
};

const expenseSlice = createSlice({
  name: 'expenses',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchMyExpenses.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchMyExpenses.fulfilled, (state, action) => {
        state.isLoading = false;
        state.expenses = action.payload;
      })
      .addCase(fetchMyExpenses.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      .addCase(fetchAllExpenses.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchAllExpenses.fulfilled, (state, action) => {
        state.isLoading = false;
        state.expenses = action.payload;
      })
      .addCase(fetchAllExpenses.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      .addCase(createExpense.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(createExpense.fulfilled, (state, action) => {
        state.isLoading = false;
        state.expenses.unshift(action.payload);
      })
      .addCase(createExpense.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      .addCase(updateExpense.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(updateExpense.fulfilled, (state, action) => {
        state.isLoading = false;
        const index = state.expenses.findIndex(exp => exp.id === action.payload.id);
        if (index !== -1) {
          state.expenses[index] = action.payload;
        }
      })
      .addCase(updateExpense.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      .addCase(deleteExpense.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(deleteExpense.fulfilled, (state, action) => {
        state.isLoading = false;
        state.expenses = state.expenses.filter(exp => exp.id !== action.payload);
      })
      .addCase(deleteExpense.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      .addCase(approveExpense.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(approveExpense.fulfilled, (state, action) => {
        state.isLoading = false;
        // Optionally update the expense status in the list
      })
      .addCase(approveExpense.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      });
  },
});

export const { clearError } = expenseSlice.actions;
export default expenseSlice.reducer; 