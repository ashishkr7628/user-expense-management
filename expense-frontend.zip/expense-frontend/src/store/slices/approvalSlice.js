import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { approvalAPI } from '../../api/approvalAPI';

// Async thunks
export const fetchPendingApprovals = createAsyncThunk(
  'approvals/fetchPendingApprovals',
  async (params, { rejectWithValue }) => {
    try {
      const response = await approvalAPI.getPendingApprovals(params);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to fetch pending approvals');
    }
  }
);

export const fetchApprovalHistory = createAsyncThunk(
  'approvals/fetchApprovalHistory',
  async (params, { rejectWithValue }) => {
    try {
      const response = await approvalAPI.getApprovalHistory(params);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to fetch approval history');
    }
  }
);

export const approveExpense = createAsyncThunk(
  'approvals/approveExpense',
  async (expenseId, { rejectWithValue }) => {
    try {
      await approvalAPI.approveExpense(expenseId);
      return expenseId;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to approve expense');
    }
  }
);

export const rejectExpense = createAsyncThunk(
  'approvals/rejectExpense',
  async (expenseId, { rejectWithValue }) => {
    try {
      await approvalAPI.rejectExpense(expenseId);
      return expenseId;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to reject expense');
    }
  }
);

export const bulkApprove = createAsyncThunk(
  'approvals/bulkApprove',
  async ({ expenseIds, approvalData }, { rejectWithValue }) => {
    try {
      const response = await approvalAPI.bulkApprove(expenseIds, approvalData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to bulk approve expenses');
    }
  }
);

export const getApprovalWorkflow = createAsyncThunk(
  'approvals/getApprovalWorkflow',
  async (expenseId, { rejectWithValue }) => {
    try {
      const response = await approvalAPI.getApprovalWorkflow(expenseId);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to fetch approval workflow');
    }
  }
);

const initialState = {
  pendingApprovals: [],
  approvalHistory: [],
  currentWorkflow: null,
  isLoading: false,
  error: null,
  totalPending: 0,
  totalHistory: 0,
  currentPage: 1,
  pageSize: 10,
  filters: {
    status: '',
    approver: '',
    dateFrom: '',
    dateTo: '',
    amountMin: '',
    amountMax: '',
  },
  selectedApprovals: [],
};

const approvalSlice = createSlice({
  name: 'approvals',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
    setCurrentWorkflow: (state, action) => {
      state.currentWorkflow = action.payload;
    },
    clearCurrentWorkflow: (state) => {
      state.currentWorkflow = null;
    },
    setFilters: (state, action) => {
      state.filters = { ...state.filters, ...action.payload };
    },
    clearFilters: (state) => {
      state.filters = initialState.filters;
    },
    setPage: (state, action) => {
      state.currentPage = action.payload;
    },
    setPageSize: (state, action) => {
      state.pageSize = action.payload;
    },
    selectApproval: (state, action) => {
      const approvalId = action.payload;
      if (state.selectedApprovals.includes(approvalId)) {
        state.selectedApprovals = state.selectedApprovals.filter(id => id !== approvalId);
      } else {
        state.selectedApprovals.push(approvalId);
      }
    },
    selectAllApprovals: (state, action) => {
      const approvalIds = action.payload;
      state.selectedApprovals = approvalIds;
    },
    clearSelectedApprovals: (state) => {
      state.selectedApprovals = [];
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch Pending Approvals
      .addCase(fetchPendingApprovals.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchPendingApprovals.fulfilled, (state, action) => {
        state.isLoading = false;
        state.pendingApprovals = action.payload.content || action.payload;
        state.totalPending = action.payload.totalElements || action.payload.length;
      })
      .addCase(fetchPendingApprovals.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      // Fetch Approval History
      .addCase(fetchApprovalHistory.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchApprovalHistory.fulfilled, (state, action) => {
        state.isLoading = false;
        state.approvalHistory = action.payload.content || action.payload;
        state.totalHistory = action.payload.totalElements || action.payload.length;
      })
      .addCase(fetchApprovalHistory.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      // Approve Expense
      .addCase(approveExpense.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(approveExpense.fulfilled, (state, action) => {
        state.isLoading = false;
        // Remove from pending approvals by ID
        state.pendingApprovals = state.pendingApprovals.filter(
          approval => approval.id !== action.payload
        );
        state.totalPending -= 1;
      })
      .addCase(approveExpense.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      // Reject Expense
      .addCase(rejectExpense.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(rejectExpense.fulfilled, (state, action) => {
        state.isLoading = false;
        // Remove from pending approvals by ID
        state.pendingApprovals = state.pendingApprovals.filter(
          approval => approval.id !== action.payload
        );
        state.totalPending -= 1;
      })
      .addCase(rejectExpense.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      // Bulk Approve
      .addCase(bulkApprove.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(bulkApprove.fulfilled, (state, action) => {
        state.isLoading = false;
        // Remove approved expenses from pending approvals
        const approvedIds = action.payload.map(approval => approval.expenseId);
        state.pendingApprovals = state.pendingApprovals.filter(
          approval => !approvedIds.includes(approval.expenseId)
        );
        state.totalPending -= approvedIds.length;
        // Add to approval history
        state.approvalHistory.unshift(...action.payload);
        state.totalHistory += approvedIds.length;
        // Clear all selections
        state.selectedApprovals = [];
      })
      .addCase(bulkApprove.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      // Get Approval Workflow
      .addCase(getApprovalWorkflow.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(getApprovalWorkflow.fulfilled, (state, action) => {
        state.isLoading = false;
        state.currentWorkflow = action.payload;
      })
      .addCase(getApprovalWorkflow.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      });
  },
});

export const {
  clearError,
  setCurrentWorkflow,
  clearCurrentWorkflow,
  setFilters,
  clearFilters,
  setPage,
  setPageSize,
  selectApproval,
  selectAllApprovals,
  clearSelectedApprovals,
} = approvalSlice.actions;

export default approvalSlice.reducer; 