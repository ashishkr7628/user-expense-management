import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  loading: {
    global: false,
    auth: false,
    expenses: false,
    approvals: false,
    analytics: false,
  },
  notifications: [],
  modals: {
    expenseForm: false,
    approvalDialog: false,
    deleteConfirm: false,
    fileUpload: false,
    userProfile: false,
  },
  sidebar: {
    open: true,
    collapsed: false,
  },
  theme: {
    mode: 'light', // 'light' or 'dark'
    primaryColor: '#1976d2',
  },
  breadcrumbs: [],
  searchQuery: '',
  selectedItems: [],
  sortConfig: {
    field: '',
    direction: 'asc',
  },
  pagination: {
    page: 1,
    pageSize: 10,
    total: 0,
  },
};

const uiSlice = createSlice({
  name: 'ui',
  initialState,
  reducers: {
    // Loading states
    setLoading: (state, action) => {
      const { key, value } = action.payload;
      if (key === 'global') {
        state.loading.global = value;
      } else {
        state.loading[key] = value;
      }
    },
    clearLoading: (state, action) => {
      const key = action.payload;
      if (key === 'global') {
        state.loading.global = false;
      } else {
        state.loading[key] = false;
      }
    },
    clearAllLoading: (state) => {
      Object.keys(state.loading).forEach(key => {
        state.loading[key] = false;
      });
    },

    // Notifications
    addNotification: (state, action) => {
      const notification = {
        id: Date.now(),
        timestamp: new Date().toISOString(),
        ...action.payload,
      };
      state.notifications.unshift(notification);
      // Keep only last 10 notifications
      if (state.notifications.length > 10) {
        state.notifications = state.notifications.slice(0, 10);
      }
    },
    removeNotification: (state, action) => {
      state.notifications = state.notifications.filter(
        notification => notification.id !== action.payload
      );
    },
    clearNotifications: (state) => {
      state.notifications = [];
    },

    // Modals
    openModal: (state, action) => {
      const modalName = action.payload;
      if (state.modals.hasOwnProperty(modalName)) {
        state.modals[modalName] = true;
      }
    },
    closeModal: (state, action) => {
      const modalName = action.payload;
      if (state.modals.hasOwnProperty(modalName)) {
        state.modals[modalName] = false;
      }
    },
    closeAllModals: (state) => {
      Object.keys(state.modals).forEach(key => {
        state.modals[key] = false;
      });
    },

    // Sidebar
    toggleSidebar: (state) => {
      state.sidebar.open = !state.sidebar.open;
    },
    setSidebarOpen: (state, action) => {
      state.sidebar.open = action.payload;
    },
    toggleSidebarCollapsed: (state) => {
      state.sidebar.collapsed = !state.sidebar.collapsed;
    },
    setSidebarCollapsed: (state, action) => {
      state.sidebar.collapsed = action.payload;
    },

    // Theme
    toggleTheme: (state) => {
      state.theme.mode = state.theme.mode === 'light' ? 'dark' : 'light';
    },
    setThemeMode: (state, action) => {
      state.theme.mode = action.payload;
    },
    setPrimaryColor: (state, action) => {
      state.theme.primaryColor = action.payload;
    },

    // Breadcrumbs
    setBreadcrumbs: (state, action) => {
      state.breadcrumbs = action.payload;
    },
    addBreadcrumb: (state, action) => {
      state.breadcrumbs.push(action.payload);
    },
    clearBreadcrumbs: (state) => {
      state.breadcrumbs = [];
    },

    // Search
    setSearchQuery: (state, action) => {
      state.searchQuery = action.payload;
    },
    clearSearchQuery: (state) => {
      state.searchQuery = '';
    },

    // Selection
    selectItem: (state, action) => {
      const itemId = action.payload;
      if (!state.selectedItems.includes(itemId)) {
        state.selectedItems.push(itemId);
      }
    },
    deselectItem: (state, action) => {
      const itemId = action.payload;
      state.selectedItems = state.selectedItems.filter(id => id !== itemId);
    },
    selectAllItems: (state, action) => {
      state.selectedItems = action.payload;
    },
    clearSelection: (state) => {
      state.selectedItems = [];
    },

    // Sorting
    setSortConfig: (state, action) => {
      state.sortConfig = action.payload;
    },
    clearSortConfig: (state) => {
      state.sortConfig = { field: '', direction: 'asc' };
    },

    // Pagination
    setPagination: (state, action) => {
      state.pagination = { ...state.pagination, ...action.payload };
    },
    setPage: (state, action) => {
      state.pagination.page = action.payload;
    },
    setPageSize: (state, action) => {
      state.pagination.pageSize = action.payload;
      state.pagination.page = 1; // Reset to first page when changing page size
    },
    setTotal: (state, action) => {
      state.pagination.total = action.payload;
    },
    resetPagination: (state) => {
      state.pagination = initialState.pagination;
    },

    // Reset UI state
    resetUI: (state) => {
      return { ...initialState, theme: state.theme }; // Preserve theme settings
    },
  },
});

export const {
  setLoading,
  clearLoading,
  clearAllLoading,
  addNotification,
  removeNotification,
  clearNotifications,
  openModal,
  closeModal,
  closeAllModals,
  toggleSidebar,
  setSidebarOpen,
  toggleSidebarCollapsed,
  setSidebarCollapsed,
  toggleTheme,
  setThemeMode,
  setPrimaryColor,
  setBreadcrumbs,
  addBreadcrumb,
  clearBreadcrumbs,
  setSearchQuery,
  clearSearchQuery,
  selectItem,
  deselectItem,
  selectAllItems,
  clearSelection,
  setSortConfig,
  clearSortConfig,
  setPagination,
  setPage,
  setPageSize,
  setTotal,
  resetPagination,
  resetUI,
} = uiSlice.actions;

export default uiSlice.reducer; 