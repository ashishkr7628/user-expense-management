import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { analyticsAPI } from '../../api/analyticsAPI';

// Async thunks
export const fetchExpenseTrends = createAsyncThunk(
  'analytics/fetchExpenseTrends',
  async (params, { rejectWithValue }) => {
    try {
      const response = await analyticsAPI.getExpenseTrends(params);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to fetch expense trends');
    }
  }
);

export const fetchCategoryBreakdown = createAsyncThunk(
  'analytics/fetchCategoryBreakdown',
  async (params, { rejectWithValue }) => {
    try {
      const response = await analyticsAPI.getCategoryBreakdown(params);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to fetch category breakdown');
    }
  }
);

export const fetchMonthlyStats = createAsyncThunk(
  'analytics/fetchMonthlyStats',
  async (params, { rejectWithValue }) => {
    try {
      const response = await analyticsAPI.getMonthlyStats(params);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to fetch monthly stats');
    }
  }
);

export const fetchApprovalStats = createAsyncThunk(
  'analytics/fetchApprovalStats',
  async (params, { rejectWithValue }) => {
    try {
      const response = await analyticsAPI.getApprovalStats(params);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to fetch approval stats');
    }
  }
);

export const generateReport = createAsyncThunk(
  'analytics/generateReport',
  async (reportParams, { rejectWithValue }) => {
    try {
      const response = await analyticsAPI.generateReport(reportParams);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to generate report');
    }
  }
);

export const exportReport = createAsyncThunk(
  'analytics/exportReport',
  async (exportParams, { rejectWithValue }) => {
    try {
      const response = await analyticsAPI.exportReport(exportParams);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to export report');
    }
  }
);

const initialState = {
  expenseTrends: [],
  categoryBreakdown: [],
  monthlyStats: {},
  approvalStats: {},
  currentReport: null,
  isLoading: false,
  error: null,
  dateRange: {
    startDate: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0],
  },
  filters: {
    category: '',
    status: '',
    approver: '',
    department: '',
  },
  chartConfig: {
    type: 'line', // 'line', 'bar', 'pie', 'doughnut'
    period: 'monthly', // 'daily', 'weekly', 'monthly', 'yearly'
  },
};

const analyticsSlice = createSlice({
  name: 'analytics',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
    setDateRange: (state, action) => {
      state.dateRange = { ...state.dateRange, ...action.payload };
    },
    setFilters: (state, action) => {
      state.filters = { ...state.filters, ...action.payload };
    },
    clearFilters: (state) => {
      state.filters = initialState.filters;
    },
    setChartConfig: (state, action) => {
      state.chartConfig = { ...state.chartConfig, ...action.payload };
    },
    setCurrentReport: (state, action) => {
      state.currentReport = action.payload;
    },
    clearCurrentReport: (state) => {
      state.currentReport = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch Expense Trends
      .addCase(fetchExpenseTrends.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchExpenseTrends.fulfilled, (state, action) => {
        state.isLoading = false;
        state.expenseTrends = action.payload;
      })
      .addCase(fetchExpenseTrends.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      // Fetch Category Breakdown
      .addCase(fetchCategoryBreakdown.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchCategoryBreakdown.fulfilled, (state, action) => {
        state.isLoading = false;
        state.categoryBreakdown = action.payload;
      })
      .addCase(fetchCategoryBreakdown.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      // Fetch Monthly Stats
      .addCase(fetchMonthlyStats.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchMonthlyStats.fulfilled, (state, action) => {
        state.isLoading = false;
        state.monthlyStats = action.payload;
      })
      .addCase(fetchMonthlyStats.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      // Fetch Approval Stats
      .addCase(fetchApprovalStats.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchApprovalStats.fulfilled, (state, action) => {
        state.isLoading = false;
        state.approvalStats = action.payload;
      })
      .addCase(fetchApprovalStats.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      // Generate Report
      .addCase(generateReport.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(generateReport.fulfilled, (state, action) => {
        state.isLoading = false;
        state.currentReport = action.payload;
      })
      .addCase(generateReport.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      // Export Report
      .addCase(exportReport.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(exportReport.fulfilled, (state, action) => {
        state.isLoading = false;
        // Handle file download
        const blob = new Blob([action.payload], { type: 'application/pdf' });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `expense-report-${new Date().toISOString().split('T')[0]}.pdf`;
        link.click();
        window.URL.revokeObjectURL(url);
      })
      .addCase(exportReport.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      });
  },
});

export const {
  clearError,
  setDateRange,
  setFilters,
  clearFilters,
  setChartConfig,
  setCurrentReport,
  clearCurrentReport,
} = analyticsSlice.actions;

export default analyticsSlice.reducer; 