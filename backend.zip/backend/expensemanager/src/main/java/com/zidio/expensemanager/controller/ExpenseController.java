package com.zidio.expensemanager.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zidio.expensemanager.model.Expense;
import com.zidio.expensemanager.service.ExpenseService;

@RestController
@RequestMapping("/api/expenses")
public class ExpenseController {

    @Autowired
    private ExpenseService expenseService;

    @PostMapping("/create")
    public Expense create(@RequestBody Expense expense, Principal principal) {
        System.out.println("👤 Request from User: " + principal.getName());

        System.out.println("🔐 Authorities in Security Context:");
        SecurityContextHolder.getContext().getAuthentication().getAuthorities()
                .forEach(auth -> System.out.println("👉 " + auth.getAuthority()));

        return expenseService.createExpense(expense, principal.getName());
    }

    @GetMapping("/my")
    public List<Expense> myExpenses(Principal principal) {
        return expenseService.getUserExpenses(principal.getName());
    }

    @GetMapping("/all")
    public List<Expense> allExpenses() {
        return expenseService.getAllExpenses();
    }
    
    @PutMapping("/approve/{id}")
    public ResponseEntity<?> approveExpense(@PathVariable Long id,
                                            @RequestParam String action,
                                            Principal principal) {
        Expense updated = expenseService.approveExpense(id, action, principal.getName());
        return ResponseEntity.ok(updated);
    }
    @DeleteMapping("/delete/{id}")
    
    public ResponseEntity<String> deleteExpense(@PathVariable Long id,
                                                Principal principal) {
        expenseService.deleteExpense(id, principal.getName());
        return ResponseEntity.ok("Expense deleted successfully.");
    }
    
    
    @PutMapping("/edit/{id}")
    
    public ResponseEntity<Expense> updateExpense(@PathVariable Long id,
                                                 @RequestBody Expense updatedExpense,
                                                 Principal principal) {
        Expense expense = expenseService.updateExpense(id, updatedExpense, principal.getName());
        return ResponseEntity.ok(expense);
    }

    
 // ExpenseController.java

    @GetMapping("/pending")
    @PreAuthorize("hasAnyRole('MANAGER', 'ADMIN')") // Role check
    public List<Expense> pendingExpenses() {
        return expenseService.getPendingExpenses();
    }
    
    @GetMapping("my/{id}")
    public ResponseEntity<Expense> getExpenseById(@PathVariable Long id, Principal principal) {
        Expense expense = expenseService.getExpenseById(id, principal.getName());
        return ResponseEntity.ok(expense);
    }



}
