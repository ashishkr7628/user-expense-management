package com.zidio.expensemanager.repository;

import com.zidio.expensemanager.model.Expense;
import com.zidio.expensemanager.model.ExpenseStatus;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ExpenseRepository extends JpaRepository<Expense, Long> {
    List<Expense> findBySubmittedBy(String submittedBy);
    List<Expense> findByStatus(ExpenseStatus status);

}

//ExpenseRepository.java

