package com.zidio.expensemanager.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zidio.expensemanager.model.Expense;
import com.zidio.expensemanager.model.ExpenseStatus;
import com.zidio.expensemanager.model.User;
import com.zidio.expensemanager.repository.ExpenseRepository;
import com.zidio.expensemanager.repository.UserRepository;

@Service
public class ExpenseService {

    @Autowired
    private ExpenseRepository expenseRepository;
    
    @Autowired
    private UserRepository userRepository;
    

    public Expense createExpense(Expense expense, String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        expense.setUser(user);
        expense.setSubmittedBy(email);
        
       // ✅ VERY IMPORTANT
        expense.setStatus(ExpenseStatus.PENDING); // default status if needed
        return expenseRepository.save(expense);
    }

    public List<Expense> getUserExpenses(String email) {
        return expenseRepository.findBySubmittedBy(email);
    }

    public List<Expense> getAllExpenses() {
        return expenseRepository.findAll();
    }
    public Expense approveExpense(Long expenseId, String action, String approverEmail) {
        Expense expense = expenseRepository.findById(expenseId)
                .orElseThrow(() -> new RuntimeException("Expense not found"));

        // only pending allowed
        if (!expense.getStatus().equals(ExpenseStatus.PENDING)) {
            throw new RuntimeException("Expense already reviewed");
        }

        if ("approve".equalsIgnoreCase(action)) {
            expense.setStatus(ExpenseStatus.APPROVED);
        } else if ("reject".equalsIgnoreCase(action)) {
            expense.setStatus(ExpenseStatus.REJECTED);
        } else {
            throw new RuntimeException("Invalid action");
        }

        return expenseRepository.save(expense);
    }
    public Expense updateExpense(Long id, Expense newData, String userEmail) {
        Expense expense = expenseRepository.findById(id)
                .filter(e -> e.getUser().getEmail().equals(userEmail))
                .orElseThrow(() -> new RuntimeException("Expense not found or unauthorized"));

        expense.setAmount(newData.getAmount());
        expense.setDescription(newData.getDescription());
        expense.setCategory(newData.getCategory());
        expense.setDate(newData.getDate());
        expense.setStatus(ExpenseStatus.PENDING); // reset status
        return expenseRepository.save(expense);
    }

    public void deleteExpense(Long id, String userEmail) {
        Expense expense = expenseRepository.findById(id)
                .filter(e -> e.getUser().getEmail().equals(userEmail))
                .orElseThrow(() -> new RuntimeException("Expense not found or unauthorized"));

        expenseRepository.delete(expense);
    }
    
 // ExpenseService.java

    public List<Expense> getPendingExpenses() {
    	return expenseRepository.findByStatus(ExpenseStatus.PENDING);
    }
    
    public Expense getExpenseById(Long id, String userEmail) {
        Expense expense = expenseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Expense not found"));

        // Allow only the user who submitted the expense or allow role-based checks here
        if (!expense.getUser().getEmail().equals(userEmail)) {
            throw new RuntimeException("Unauthorized to view this expense");
        }

        return expense;
    }




}
