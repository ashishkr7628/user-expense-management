package com.zidio.expensemanager.model;

public enum Role {
    EMPLOYEE,
    MANAGER,
    ADMIN
}
