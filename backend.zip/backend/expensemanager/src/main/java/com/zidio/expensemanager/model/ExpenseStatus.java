package com.zidio.expensemanager.model;

public enum ExpenseStatus {
    PENDING,
    APPROVED,
    REJECTED
}
