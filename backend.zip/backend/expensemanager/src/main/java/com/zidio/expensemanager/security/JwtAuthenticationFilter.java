package com.zidio.expensemanager.security;

import com.zidio.expensemanager.model.User;
import com.zidio.expensemanager.service.UserService;
import com.zidio.expensemanager.util.JwtUtil;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UserService userService;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        String authHeader = request.getHeader("Authorization");

        System.out.println("🔍 Incoming Request URL: " + request.getRequestURI());

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);
            System.out.println("✅ JWT Token Received: " + token);

            if (jwtUtil.validateToken(token)) {
                String email = jwtUtil.extractUsername(token);
                System.out.println("📧 Email from Token: " + email);

                User user = userService.findByEmail(email).orElse(null);
                if (user != null) {
                    String role = user.getRole().name();
                    System.out.println("👤 User Role: " + role);

                    UsernamePasswordAuthenticationToken auth =
                            new UsernamePasswordAuthenticationToken(
                                    email,
                                    null,
                                    List.of(new SimpleGrantedAuthority("ROLE_" + role))
                            );

                    SecurityContextHolder.getContext().setAuthentication(auth);
                    System.out.println("✅ Auth Set in Context");
                } else {
                    System.out.println("❌ User Not Found in DB");
                }
            } else {
                System.out.println("❌ Invalid JWT Token");
            }
        } else {
            System.out.println("⚠️ No Authorization Header Found");
        }

        filterChain.doFilter(request, response);
    }
}